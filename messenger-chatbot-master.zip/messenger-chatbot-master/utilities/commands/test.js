module.exports = ({ api, event, userInfo }) => {
  console.log(userInfo);
  api.sendMessage(`Hi ${userInfo.name}`, event.threadID, event.messageID);
};
