module.exports = {
  name: "Kei",
  prefix: "¢",
  admins: ["100081144393297"],
};
